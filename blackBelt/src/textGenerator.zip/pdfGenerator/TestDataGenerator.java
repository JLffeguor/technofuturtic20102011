package pdfGenerator;

public class TestDataGenerator {

	Section section1 = new Section(
			"1. Exceptions",
			"</p>Exceptions and Errors are special Java objects families used to describe problems that occurs in applications. They can be split into 3 sub families having a common ancestor (Throwable): Errors, Runtime Exceptions, Checked Exceptions.</p>");
	Section section11 = new Section(
			"1.1. Runtime Exceptions",
			"<p>Runtime Exceptions are problems that happen in your application because you've written bad code. Try this example in Eclipse:</p>[code]    public static void main(String[] args){         BankAccount ba = null;         printAccountDetails(ba);     }      public static void printAccountDetails(BankAccount ba){         System.out.println(ba.getAccountNumber() + \" - \" + ba.getBalance());     }[/code]<p>The above example throws a NullPointerException because the getAccountNumber() method is called using a null reference.</p>");
	Section section12 = new Section(
			"1.2. Prefixes & Postfixes",
			"Some prefixes and postfixes may be"
					+ " used with primitive literals:* Hexadecimal (base 16) is denoted by a leading 0X or 0x "
					+ "followed by 1...9 and a...f either in upper or lowercase* Octal (base 8) is denoted by a "
					+ "leading 0 followed by 1...7. Example: 012 is the same as 0xA is the same as 1 * A trailing "
					+ "character (either upper or lowercase) after a literal value establishes its type: L means long,"
					+ " F float, D double.* e means ten to the power. ex : 1.39 e-47f means 1.39 * 10-47Example:\n");
	Section section13 = new Section("syntax 1.3", "");
	Section section2 = new Section(
			"2. Classloading",
			"The JVM includes a classloading mechanism that is necessary "
					+ "to understand when weird deployment runtime problems happen.\n");
	Section section21 = new Section(
			"2.1. Files",
			"As you know, source code is stored in .java files. The compiler "
					+ "produces .class files with bytecode.In the following diagram, you see these elements, with the ClassLoader "
					+ "responsible of finding/loading the .class files at runtime.\n");
	Section section111 = new Section(
			"<h1> 1.1.1 Exercice <h1>",
			"<p>Execute the following steps</p></br><ul><p>    </p><li>Run a program that throws a NullPointerException (as on the example above).</li><p>    </p><li>Build a new class that iterates through an array but goes too far</li><p>    </p><li>Check the Java SE JavaDoc, locate Throwable, Exception and browse through the subclasses of RuntimeException. Note that the notion of subclass will be seen in a later chapter.</li><p></p></ul>");

	public void generate() {
		section1.getSubSections().add(section11);
		section1.getSubSections().add(section12);
		section1.getSubSections().add(section13);
		section11.getSubSections().add(section111);// create a sub-subSection
		section2.getSubSections().add(section21);
	}

}
