package pdfGenerator;

import coursepage.CourseTextFormatter;


public class PdfGenerator {

	public void recursiveWalk(Section currentSection) {
		// print data for print the PDF in good order
		// code julien
		CourseTextFormatter sectionFormatter = new CourseTextFormatter("",currentSection.getBody());
		System.out.println(currentSection.getTitle());
		System.out.println(sectionFormatter.format());
		try {
			if (!currentSection.getSubSections().isEmpty()) {
				for (Section sSection : currentSection.getSubSections()) {
					recursiveWalk(sSection);
				}
			}
		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
	}
}
